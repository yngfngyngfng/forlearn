class Variables:
  vdict = {}